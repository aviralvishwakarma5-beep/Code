# Event Registration System — Backend API

A REST API built with **Express.js** and **MongoDB (Mongoose)** for managing events and user registrations. Includes JWT authentication, role-based access for event organizers, and full registration lifecycle (register / view / cancel).

## Tech Stack

- **Runtime:** Node.js + Express.js
- **Database:** MongoDB with Mongoose ODM
- **Auth:** JSON Web Tokens (JWT) + bcrypt password hashing

## Data Models

**User** — `name`, `email` (unique), `password` (hashed), `role` (`user` | `organizer` | `admin`)

**Event** — `title`, `description`, `category`, `date`, `location`, `capacity`, `organizer` (ref User), `isCancelled`

**Registration** — `user` (ref), `event` (ref), `status` (`confirmed` | `cancelled`), `formResponses` (free-form key/value form data). A unique compound index on `(user, event)` prevents duplicate active registrations, and re-registering after a cancellation reactivates the same record instead of creating a duplicate.

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# then edit .env and set MONGO_URI / JWT_SECRET

# 3. (Optional) seed sample data — creates 1 organizer, 1 user, 3 events
npm run seed

# 4. Run the server
npm run dev      # with nodemon (auto-restart)
npm start        # plain node
```

The API will be available at `http://localhost:5000/api`.

You need a running MongoDB instance — either locally (`mongodb://127.0.0.1:27017/event_registration`) or a hosted one like MongoDB Atlas (paste its connection string into `MONGO_URI`).

## Authentication

Send the JWT returned from register/login as a Bearer token:

```
Authorization: Bearer <token>
```

Registering with `"role": "organizer"` in the body grants organizer permissions. Nobody can self-assign the `admin` role through the API — that must be set directly in the database.

## API Endpoints

### Auth
| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create an account (`name`, `email`, `password`, optional `role: "organizer"`) |
| POST | `/api/auth/login` | Public | Log in, returns JWT |
| GET | `/api/auth/me` | Private | Get current user's profile |

### Events
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/api/events` | Public | List events. Query params: `page`, `limit`, `search`, `category`, `upcoming=true` |
| GET | `/api/events/:id` | Public | Event details, including `seatsRemaining` |
| POST | `/api/events` | Organizer/Admin | Create an event |
| PUT | `/api/events/:id` | Owner/Admin | Update an event |
| DELETE | `/api/events/:id` | Owner/Admin | Delete an event (and its registrations) |
| GET | `/api/events/:id/registrations` | Owner/Admin | List everyone registered for an event |
| POST | `/api/events/:id/register` | Private | Register the logged-in user for the event |

### Registrations
| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/api/registrations/me` | Private | List the logged-in user's registrations (optional `?status=confirmed\|cancelled`) |
| GET | `/api/registrations/:id` | Owner/Admin | Get a single registration |
| DELETE | `/api/registrations/:id` | Owner/Admin | Cancel a registration (frees up a seat) |

## Example Requests

**Register a user**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Bob","email":"bob@example.com","password":"password123"}'
```

**Create an event (organizer)**
```bash
curl -X POST http://localhost:5000/api/events \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <ORGANIZER_TOKEN>" \
  -d '{"title":"Tech Conference","description":"Annual tech meet","date":"2026-12-01","location":"Lucknow","capacity":100}'
```

**Register for an event**
```bash
curl -X POST http://localhost:5000/api/events/<EVENT_ID>/register \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <USER_TOKEN>" \
  -d '{"formResponses":{"tShirtSize":"M"}}'
```

**Cancel a registration**
```bash
curl -X DELETE http://localhost:5000/api/registrations/<REGISTRATION_ID> \
  -H "Authorization: Bearer <USER_TOKEN>"
```

## Business Rules Enforced

- An event cannot be over-booked — registration is rejected once `confirmed` registrations reach `capacity`.
- A user cannot register twice for the same event while their registration is active.
- Cancelling frees the seat immediately for others.
- Only the organizer who created an event (or an admin) can update, delete it, or view its registrant list.
- Users can only view/cancel their own registrations (admins can act on any).

## Project Structure

```
event-registration-system/
├── config/
│   ├── db.js          # MongoDB connection
│   └── seed.js         # Sample data generator
├── controllers/
│   ├── authController.js
│   ├── eventController.js
│   └── registrationController.js
├── middleware/
│   ├── auth.js          # JWT verification + role authorization
│   └── errorHandler.js
├── models/
│   ├── User.js
│   ├── Event.js
│   └── Registration.js
├── routes/
│   ├── authRoutes.js
│   ├── eventRoutes.js
│   └── registrationRoutes.js
├── server.js
├── package.json
└── .env.example
```

## Notes / Possible Extensions

- Add pagination to `/registrations/me` if a user could have many registrations.
- Add email confirmation on registration (e.g. via Nodemailer/SendGrid).
- Add rate limiting (`express-rate-limit`) on auth routes.
- Swap Mongoose/MongoDB for PostgreSQL + Sequelize/Prisma if a relational DB is preferred — the model shapes translate directly to two tables (`events`, `registrations`) with a foreign key/unique constraint on `(user_id, event_id)`.
