const express = require('express');
const router = express.Router();
const {
  getMyRegistrations,
  getRegistration,
  cancelRegistration,
} = require('../controllers/registrationController');
const { protect } = require('../middleware/auth');

router.get('/me', protect, getMyRegistrations);
router.get('/:id', protect, getRegistration);
router.delete('/:id', protect, cancelRegistration);

module.exports = router;
