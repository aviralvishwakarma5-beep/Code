const express = require('express');
const router = express.Router();
const {
  getEvents,
  getEvent,
  createEvent,
  updateEvent,
  deleteEvent,
  getEventRegistrations,
} = require('../controllers/eventController');
const { registerForEvent } = require('../controllers/registrationController');
const { protect, authorize } = require('../middleware/auth');

// Public
router.get('/', getEvents);
router.get('/:id', getEvent);

// Private - organizer/admin only
router.post('/', protect, authorize('organizer', 'admin'), createEvent);
router.put('/:id', protect, authorize('organizer', 'admin'), updateEvent);
router.delete('/:id', protect, authorize('organizer', 'admin'), deleteEvent);
router.get('/:id/registrations', protect, authorize('organizer', 'admin'), getEventRegistrations);

// Private - any logged in user can register for an event
router.post('/:id/register', protect, registerForEvent);

module.exports = router;
