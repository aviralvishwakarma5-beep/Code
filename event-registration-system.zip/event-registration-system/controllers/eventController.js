const Event = require('../models/Event');
const Registration = require('../models/Registration');

// @desc    Get list of events (supports pagination, search, category, upcoming-only filter)
// @route   GET /api/events?page=1&limit=10&search=music&category=Tech&upcoming=true
// @access  Public
exports.getEvents = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 10, 1);
    const skip = (page - 1) * limit;

    const filter = { isCancelled: false };

    if (req.query.search) {
      filter.$or = [
        { title: { $regex: req.query.search, $options: 'i' } },
        { description: { $regex: req.query.search, $options: 'i' } },
      ];
    }

    if (req.query.category) {
      filter.category = { $regex: `^${req.query.category}$`, $options: 'i' };
    }

    if (req.query.upcoming === 'true') {
      filter.date = { $gte: new Date() };
    }

    const [events, total] = await Promise.all([
      Event.find(filter)
        .populate('organizer', 'name email')
        .populate('registrationCount')
        .sort({ date: 1 })
        .skip(skip)
        .limit(limit),
      Event.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      count: events.length,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      data: events,
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single event details, including seats remaining
// @route   GET /api/events/:id
// @access  Public
exports.getEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate('organizer', 'name email')
      .populate('registrationCount');

    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    const seatsRemaining = event.capacity - (event.registrationCount || 0);

    res.status(200).json({
      success: true,
      data: { ...event.toObject(), seatsRemaining: Math.max(seatsRemaining, 0) },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Create a new event
// @route   POST /api/events
// @access  Private (organizer, admin)
exports.createEvent = async (req, res, next) => {
  try {
    const { title, description, category, date, location, capacity } = req.body;

    if (!title || !description || !date || !location || !capacity) {
      return res.status(400).json({
        success: false,
        message: 'title, description, date, location and capacity are required',
      });
    }

    const event = await Event.create({
      title,
      description,
      category,
      date,
      location,
      capacity,
      organizer: req.user._id,
    });

    res.status(201).json({ success: true, data: event });
  } catch (err) {
    next(err);
  }
};

// @desc    Update an event
// @route   PUT /api/events/:id
// @access  Private (organizer who owns it, or admin)
exports.updateEvent = async (req, res, next) => {
  try {
    let event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    const isOwner = event.organizer.toString() === req.user._id.toString();
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to update this event' });
    }

    const allowedFields = ['title', 'description', 'category', 'date', 'location', 'capacity', 'isCancelled'];
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) event[field] = req.body[field];
    });

    await event.save();
    res.status(200).json({ success: true, data: event });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete an event
// @route   DELETE /api/events/:id
// @access  Private (organizer who owns it, or admin)
exports.deleteEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    const isOwner = event.organizer.toString() === req.user._id.toString();
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this event' });
    }

    await Registration.deleteMany({ event: event._id });
    await event.deleteOne();

    res.status(200).json({ success: true, message: 'Event and its registrations were deleted' });
  } catch (err) {
    next(err);
  }
};

// @desc    Get all registrations for a specific event (organizer view)
// @route   GET /api/events/:id/registrations
// @access  Private (organizer who owns it, or admin)
exports.getEventRegistrations = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found' });
    }

    const isOwner = event.organizer.toString() === req.user._id.toString();
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to view these registrations' });
    }

    const registrations = await Registration.find({ event: event._id, status: 'confirmed' }).populate(
      'user',
      'name email'
    );

    res.status(200).json({ success: true, count: registrations.length, data: registrations });
  } catch (err) {
    next(err);
  }
};
