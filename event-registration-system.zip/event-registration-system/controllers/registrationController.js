const mongoose = require('mongoose');
const Event = require('../models/Event');
const Registration = require('../models/Registration');

// @desc    Register the logged-in user for an event
// @route   POST /api/events/:id/register
// @access  Private
exports.registerForEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);

    if (!event || event.isCancelled) {
      return res.status(404).json({ success: false, message: 'Event not found or has been cancelled' });
    }

    if (new Date(event.date) < new Date()) {
      return res.status(400).json({ success: false, message: 'Cannot register for an event that has already happened' });
    }

    const confirmedCount = await Registration.countDocuments({ event: event._id, status: 'confirmed' });
    if (confirmedCount >= event.capacity) {
      return res.status(400).json({ success: false, message: 'This event is fully booked' });
    }

    // Check for an existing registration (possibly a previously cancelled one)
    let registration = await Registration.findOne({ user: req.user._id, event: event._id });

    if (registration) {
      if (registration.status === 'confirmed') {
        return res.status(400).json({ success: false, message: 'You are already registered for this event' });
      }
      // Re-activate a cancelled registration
      registration.status = 'confirmed';
      registration.formResponses = req.body.formResponses || registration.formResponses;
      await registration.save();
    } else {
      registration = await Registration.create({
        user: req.user._id,
        event: event._id,
        formResponses: req.body.formResponses || {},
      });
    }

    res.status(201).json({ success: true, message: 'Registration successful', data: registration });
  } catch (err) {
    // Handles the rare race-condition duplicate key error from the unique index
    if (err.code === 11000) {
      return res.status(400).json({ success: false, message: 'You are already registered for this event' });
    }
    next(err);
  }
};

// @desc    Get all of the logged-in user's registrations
// @route   GET /api/registrations/me
// @access  Private
exports.getMyRegistrations = async (req, res, next) => {
  try {
    const filter = { user: req.user._id };
    if (req.query.status) {
      filter.status = req.query.status;
    }

    const registrations = await Registration.find(filter)
      .populate('event')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: registrations.length, data: registrations });
  } catch (err) {
    next(err);
  }
};

// @desc    Get a single registration by id (owner only)
// @route   GET /api/registrations/:id
// @access  Private
exports.getRegistration = async (req, res, next) => {
  try {
    const registration = await Registration.findById(req.params.id).populate('event');

    if (!registration) {
      return res.status(404).json({ success: false, message: 'Registration not found' });
    }

    const isOwner = registration.user.toString() === req.user._id.toString();
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to view this registration' });
    }

    res.status(200).json({ success: true, data: registration });
  } catch (err) {
    next(err);
  }
};

// @desc    Cancel a registration
// @route   DELETE /api/registrations/:id
// @access  Private (owner, or admin)
exports.cancelRegistration = async (req, res, next) => {
  try {
    const registration = await Registration.findById(req.params.id);

    if (!registration) {
      return res.status(404).json({ success: false, message: 'Registration not found' });
    }

    const isOwner = registration.user.toString() === req.user._id.toString();
    if (!isOwner && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to cancel this registration' });
    }

    if (registration.status === 'cancelled') {
      return res.status(400).json({ success: false, message: 'Registration is already cancelled' });
    }

    registration.status = 'cancelled';
    await registration.save();

    res.status(200).json({ success: true, message: 'Registration cancelled successfully', data: registration });
  } catch (err) {
    next(err);
  }
};
