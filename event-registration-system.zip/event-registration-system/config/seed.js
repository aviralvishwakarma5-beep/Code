// Populates the database with sample users and events for local testing/demo.
// Run with: npm run seed
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Event = require('../models/Event');
const Registration = require('../models/Registration');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for seeding...');

    await Promise.all([
      User.deleteMany({}),
      Event.deleteMany({}),
      Registration.deleteMany({}),
    ]);
    console.log('Cleared existing users, events, and registrations.');

    const organizer = await User.create({
      name: 'Alice Organizer',
      email: 'alice@example.com',
      password: 'password123',
      role: 'organizer',
    });

    const user = await User.create({
      name: 'Bob Attendee',
      email: 'bob@example.com',
      password: 'password123',
      role: 'user',
    });

    const events = await Event.insertMany([
      {
        title: 'Web Development Bootcamp',
        description: 'A full day workshop covering modern web development practices.',
        category: 'Tech',
        date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        location: 'Lucknow, India',
        capacity: 50,
        organizer: organizer._id,
      },
      {
        title: 'City Music Festival',
        description: 'An evening of live music from local artists.',
        category: 'Music',
        date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        location: 'Central Park',
        capacity: 200,
        organizer: organizer._id,
      },
      {
        title: 'Startup Networking Night',
        description: 'Meet founders, investors, and fellow builders over drinks.',
        category: 'Networking',
        date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        location: 'Downtown Business Hub',
        capacity: 2,
        organizer: organizer._id,
      },
    ]);

    await Registration.create({
      user: user._id,
      event: events[0]._id,
      formResponses: { tShirtSize: 'L' },
    });

    console.log('Seed data created successfully:');
    console.log(`  Organizer login -> email: alice@example.com | password: password123`);
    console.log(`  User login      -> email: bob@example.com   | password: password123`);
    console.log(`  Created ${events.length} events, 1 registration.`);

    process.exit(0);
  } catch (err) {
    console.error('Seeding failed:', err);
    process.exit(1);
  }
};

seed();
