const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    event: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Event',
      required: true,
    },
    status: {
      type: String,
      enum: ['confirmed', 'cancelled'],
      default: 'confirmed',
    },
    // Free-form answers a user might submit with a registration form
    // e.g. { dietaryPreference: 'Vegan', tShirtSize: 'M' }
    formResponses: {
      type: Map,
      of: String,
      default: {},
    },
  },
  { timestamps: true }
);

// A user can only have ONE active registration record per event.
// (We still allow re-registering after cancellation by reusing the same doc.)
registrationSchema.index({ user: 1, event: 1 }, { unique: true });

module.exports = mongoose.model('Registration', registrationSchema);
